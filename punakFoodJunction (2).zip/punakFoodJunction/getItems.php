<?php
include "config.php";

$category = $_GET['category'];

$Qry = "SELECT ItemName, ItemID FROM menu_item WHERE CatagoryID = '$category'";

$res = mysqli_query($con, $Qry);

$options = "";

while ($r = mysqli_fetch_array($res)) {
    $options .= '<option value="' . $r["ItemID"] . '">' . $r["ItemName"] . '</option>';
}

echo $options;
?>
