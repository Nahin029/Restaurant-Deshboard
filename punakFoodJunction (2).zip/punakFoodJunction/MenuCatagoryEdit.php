<?php
require_once "config.php";
session_start();
if(!isset($_SESSION["login"]))
header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php";?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
           <?php include "NavTop.php"; ?>
            <!-- Navbar End -->
            <?php

require_once "config.php";
$Qry="Select * from menu_catagory where ID=".$_GET["EditID"];
$r=mysqli_query($con,$Qry);
$row=mysqli_fetch_array($r);

?>

<!-------apply button--------->

            <?php
include "config.php";

if(isset($_POST['Add'])){
    $ID= $_POST["id"];
    $CN= $_POST["CatagoryID"];
	$SE= $_POST["Catagoryname"];
    
    $Qry="UPDATE `menu_catagory` SET `CatagoryID`='$CN',`CatagoryName`='$SE' WHERE  ID='$ID' ";

	

	if(mysqli_query($con,$Qry)){
        
		echo '<script language="javascript">alert("All Data has been sucessfully Updateed!!! ");window.location.href = "MenuCatagory.php"; </script>';
        
    }
	else {
		echo '<script language="javascript">alert("Somthing wrong!! Data is not Updateed!!! "); window.back();</script>';
	}
}
?>

            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row  bg-light rounded align-items-center  mx-0">
                <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Update Catagory</h6>
                            <form action="" method="POST" >
                            <div class="row mb-4" >
                                    <label for="Seme" class="col-sm-4 col-form-label"></label>
                                    <div class="col-sm-8">
                                        <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row["ID"];?>" required>
                                    </div>
                                </div>
                            <div class="row mb-4" >
                                    <label for="CatagoryID" class="col-sm-4 col-form-label">Catagory ID</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="CatagoryID" name="CatagoryID" value="<?php echo $row["CatagoryID"];?>" required>
                                    </div>
                                </div>
                                <div class="row mb-4" >
                                    <label for="Catagoryname" class="col-sm-4 col-form-label">Catagory Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="Catagoryname" name="Catagoryname" value="<?php echo $row["CatagoryName"];?>">
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary" name="Add">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Blank End -->


            <!-- Footer Start -->
            <?php include "Footer.php";?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>