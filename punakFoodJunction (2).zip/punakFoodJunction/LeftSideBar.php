<div class="navbar-nav w-100">
                    <a href="index.php" class="nav-item nav-link"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-cog me-2"></i>Resturent</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="ResturentList.php" class="dropdown-item">Resturent List</a>
                            
                        </div>
                        <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-users me-2"></i>Stuff</a>
                        <div class="dropdown-menu bg-transparent border-0">
                        <a href="Stuff1.php" class="dropdown-item">Add Stuff</a>
                        <a href="viewStuff.php" class="dropdown-item">view staff</a>
                            
                            
                        </div>
                        <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Menu</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="MenuCatagory.php" class="dropdown-item">Catagory</a>
                            <a href="MenuItem.php" class="dropdown-item">Item</a>
                            
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Buying/Selling</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="BuyProduct.php" class="dropdown-item">Buy Product</a>
                            <a href="SellProduct.php" class="dropdown-item">Sell Product</a>
                            
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Report</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="buying.php" class="dropdown-item">Buying Report</a>
                            <a href="Selling.php" class="dropdown-item">Selling Report</a>
                            
                        </div>
                    </div>
                    <!-- <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Elements</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="button.html" class="dropdown-item">Buttons</a>
                            <a href="typography.html" class="dropdown-item">Typography</a>
                            <a href="element.html" class="dropdown-item">Other Elements</a>
                        </div>
                    </div> -->
                    
                </div>