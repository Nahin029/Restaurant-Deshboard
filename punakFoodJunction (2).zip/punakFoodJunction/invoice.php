<?php
// Start the session and include the configuration file
session_start();
require_once "config.php";

// Check if the user is logged in, otherwise redirect to the login page
if(!isset($_SESSION["login"])) {
    header("location: signin.php");
    exit();
}

// Check if the 'order_id' parameter is set in the URL
if(isset($_GET['order_id'])) {
    // Sanitize the order_id
    $orderID = mysqli_real_escape_string($con, $_GET['order_id']);

    // Retrieve the order details from the database
    $sql = "SELECT * FROM orders WHERE OrderID = '$orderID'";
    $result = mysqli_query($con, $sql);

    if ($result) {
        // Fetch the order details
        $orderDetails = mysqli_fetch_assoc($result);
    } else {
        echo "Error fetching order details: " . mysqli_error($con);
    }
} else {
    echo "Order ID not specified.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php"; ?>
    <style>
        .invoice-container {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
        }

        .invoice-header,
        .invoice-body,
        .invoice-footer {
            padding: 10px;
        }

        .invoice-header {
            text-align: center;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ccc;
        }

        .invoice-body table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .invoice-body th,
        .invoice-body td {
            border: 1px solid #ccc;
            padding: 8px;
        }

        .invoice-footer {
    text-align: right;
    font-weight: bold;
    padding-right: 110px;
}

    </style>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->

        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "NavTop.php"; ?>
            <!-- Navbar End -->

            <!-- Invoice Details Start -->
            <div class="invoice-container">
            <button onclick="printInvoice()" class="btn btn-primary"><i class="fa fa-print" aria-hidden="true"></i></button>
                <div class="invoice-header">
                    <h1>Invoice</h1>
                    <p>Order ID: <?php echo $orderDetails['OrderID']; ?></p>
                    <p>Order Date: <?php echo $orderDetails['Date']; ?></p>
                </div>
                <div class="invoice-body">
                    <table>
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $sql = "SELECT * FROM orders WHERE OrderID = '$orderID'";
                            $result = mysqli_query($con, $sql);
                            $grandTotal = 0;
                           while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>$row[itemName]</td>";
                                    echo "<td>$row[quantity]</td>";
                                    echo "<td>$row[itemPrice]</td>";
                                    echo "<td>$row[totalPrice]</td>";
                                    echo "</tr>";
                                    $grandTotal += $row['totalPrice'];
                           }
                          
                            ?>

                            
                            <!-- Add more rows if needed -->
                        </tbody>
                    </table>
                </div>
                <div class="invoice-footer">
                    Total: <?php echo $grandTotal; ?> tk
                </div>
            </div>
            <!-- Invoice Details End -->

            <!-- Footer Start -->
            <?php include "Footer.php"; ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script>
    function printInvoice() {
        window.print();
    }
</script>
</body>

</html>
