<?php

require_once "config.php";

$CatagoryID = $_GET["CatagoryID"];
$Qry = "SELECT DISTINCT ItemName, ItemID FROM menu_items WHERE CatagoryID=$CatagoryID ORDER BY ItemName";
$res = mysqli_query($con, $Qry);
$options = "";
while ($r = mysqli_fetch_array($res)) {
    $options .= '<option value="' . $r["ItemID"] . '">' . $r["ItemName"] . '</option>';
}

echo $options;


mysqli_close($con);
?>
