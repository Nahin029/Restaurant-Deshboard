<?php
include "config.php";

if(isset($_GET['category'])) {
    $category = $_GET['category'];

    // Query the database to get items for the selected category
    $itemQuery = "SELECT * FROM menu_item WHERE CatagoryID = '$category'";
    $itemResult = mysqli_query($con, $itemQuery);

    if ($itemResult) {
        while ($itemRow = mysqli_fetch_assoc($itemResult)) {
            // Output each item as a card (modify this as per your HTML structure)
            echo '<div class="card col-md-4 mb-4">';
            echo '<div class="card">';
            echo '<img src="' . $itemRow['image_path'] . '" width="50px" height="180px"class="card-img-top" alt="Item Image">';
            
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . $itemRow['ItemName'] . '</h5>';
            echo '<p class="card-text">Price: $' . $itemRow['ItemPrice'] . '</p>';
           // Modify the button in your existing PHP loop that generates the items
           echo '<button class="btn btn-primary add-to-cart" data-id="' . $itemRow['ItemID'] . '" data-name="' . $itemRow['ItemName'] . '" data-price="' . $itemRow['ItemPrice'] . '">Add to Cart</button>';



            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "Error fetching items: " . mysqli_error($con);
    }
}
?>

