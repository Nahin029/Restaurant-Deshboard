-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2023 at 03:09 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `punak`
--

-- --------------------------------------------------------

--
-- Table structure for table `buy_items`
--

CREATE TABLE `buy_items` (
  `ID` int(10) NOT NULL,
  `date` date NOT NULL,
  `CatagoryID` varchar(10) NOT NULL,
  `ItemID` varchar(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `UnitPrice` decimal(10,2) NOT NULL,
  `TotalPrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buy_items`
--

INSERT INTO `buy_items` (`ID`, `date`, `CatagoryID`, `ItemID`, `quantity`, `UnitPrice`, `TotalPrice`) VALUES
(24, '2023-09-26', 'C1', 'Cbw', 1, '200.00', '200.00'),
(25, '2023-09-26', 'B1', 'RB1', 5, '80.00', '400.00'),
(26, '2023-09-26', 'B1', 'RB1', 5, '80.00', '400.00'),
(27, '2023-09-25', 'CH1', 'Cvc', 5, '120.00', '600.00');

-- --------------------------------------------------------

--
-- Table structure for table `buy_product`
--

CREATE TABLE `buy_product` (
  `ID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `ItemName` varchar(200) NOT NULL,
  `UnitePrice` decimal(10,2) NOT NULL,
  `Quantity` int(10) NOT NULL,
  `TotalPrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buy_product`
--

INSERT INTO `buy_product` (`ID`, `Date`, `ItemName`, `UnitePrice`, `Quantity`, `TotalPrice`) VALUES
(2, '2023-09-26', 'chicken', '380.00', 5, '1900.00'),
(3, '2023-09-23', 'Moida', '58.00', 2, '116.00');

-- --------------------------------------------------------

--
-- Table structure for table `menu_catagory`
--

CREATE TABLE `menu_catagory` (
  `ID` int(7) NOT NULL,
  `CatagoryID` varchar(50) NOT NULL,
  `CatagoryName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu_catagory`
--

INSERT INTO `menu_catagory` (`ID`, `CatagoryID`, `CatagoryName`) VALUES
(1, 'B1', 'Burger'),
(3, 'p1', 'Pasta'),
(5, 'CH1', 'Chowmin'),
(6, 'C1', 'Chicken'),
(7, 'B2', 'BEVERAGES'),
(8, 'R1', 'RICE BOWLZ');

-- --------------------------------------------------------

--
-- Table structure for table `menu_item`
--

CREATE TABLE `menu_item` (
  `ID` int(7) NOT NULL,
  `ItemID` varchar(50) NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `ItemPrice` int(10) NOT NULL,
  `CatagoryID` varchar(10) NOT NULL,
  `image_path` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu_item`
--

INSERT INTO `menu_item` (`ID`, `ItemID`, `ItemName`, `ItemPrice`, `CatagoryID`, `image_path`) VALUES
(3, 'RB1', 'Regualar Burger', 80, 'B1', 'images/6482cfbe8a61d.jpg'),
(4, 'CCB1', 'Chicken Chesse Burger', 100, 'B1', 'images/burger2.jpg'),
(7, 'Bcc', 'Crispy Chicken Burger', 110, 'B1', 'images/images (3).jpg'),
(8, 'prc', 'Chicken Red Pasta', 120, 'p1', 'images/Red-Sauce-Pasta.jpg'),
(9, 'pcc', 'Chicken Cheese Pasta', 150, 'p1', 'images/goats-cheese-pasta-1sq.jpg'),
(10, 'Cvc', 'Vegetable Chowmein', 120, 'CH1', 'images/download (2).jpg'),
(11, 'Ccc', 'Crispy Chicken fry', 80, 'C1', 'images/download (3).jpg'),
(12, 'Cbw', 'BBQ Wings', 200, 'C1', 'images/download (4).jpg'),
(13, 'BEcc', 'Cold Coffe', 80, 'B2', 'images/Cafe-style-cold-coffee-with-icecream.jpg'),
(14, 'BEl', 'lassi', 70, 'B2', 'images/download (5).jpg'),
(15, 'BEmj', 'Mango Juice', 80, 'B2', 'images/download (6).jpg'),
(16, 'BEp', 'pepsi 250ml', 25, 'B2', 'images/download (7).jpg'),
(17, 'BEs', 'Sprite 250ml', 25, 'B2', 'images/8907525040110.jpg'),
(18, 'Rrb', 'RICE BOWLZ 1', 120, 'R1', 'images/vwS01VniI4H7JfmHZqMvlt69B.jpg'),
(19, 'Rrb2', 'RICE BOWLZ 2', 150, 'R1', 'images/2GAipyiQI9OUgzlf4L0ZlnVoo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `resturent`
--

CREATE TABLE `resturent` (
  `ID` int(11) NOT NULL,
  `ResturentName` varchar(50) NOT NULL,
  `ResturentType` varchar(50) NOT NULL,
  `Address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resturent`
--

INSERT INTO `resturent` (`ID`, `ResturentName`, `ResturentType`, `Address`) VALUES
(22, 'Punak The Food Junction', 'Fast Food', 'Police Line ');

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `ID` int(3) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signin`
--

INSERT INTO `signin` (`ID`, `UserName`, `Password`) VALUES
(1, 'Admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `stuff`
--

CREATE TABLE `stuff` (
  `ID` int(5) NOT NULL,
  `EName` varchar(50) NOT NULL,
  `FName` varchar(50) NOT NULL,
  `Gander` varchar(50) NOT NULL,
  `Catogry` varchar(50) NOT NULL,
  `Mobile` text NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stuff`
--

INSERT INTO `stuff` (`ID`, `EName`, `FName`, `Gander`, `Catogry`, `Mobile`, `Address`, `Image`) VALUES
(11, 'Nahin1', 'asdajdalmd', 'Male', '', '01953413050', 'mymensingh', 'images/6482cfbe8a61d.jpg'),
(12, 'Nahin', 'md', 'Male', 'Waiter', '01953413050', 'mymensingh', 'images/64aa5eaa17e2e.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buy_items`
--
ALTER TABLE `buy_items`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `buy_product`
--
ALTER TABLE `buy_product`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `menu_catagory`
--
ALTER TABLE `menu_catagory`
  ADD PRIMARY KEY (`ID`,`CatagoryID`);

--
-- Indexes for table `menu_item`
--
ALTER TABLE `menu_item`
  ADD PRIMARY KEY (`ID`,`ItemID`);

--
-- Indexes for table `resturent`
--
ALTER TABLE `resturent`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `signin`
--
ALTER TABLE `signin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `stuff`
--
ALTER TABLE `stuff`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buy_items`
--
ALTER TABLE `buy_items`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `buy_product`
--
ALTER TABLE `buy_product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menu_catagory`
--
ALTER TABLE `menu_catagory`
  MODIFY `ID` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `menu_item`
--
ALTER TABLE `menu_item`
  MODIFY `ID` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `resturent`
--
ALTER TABLE `resturent`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `signin`
--
ALTER TABLE `signin`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stuff`
--
ALTER TABLE `stuff`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
