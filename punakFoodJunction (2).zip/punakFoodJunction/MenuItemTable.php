<?php
require_once "config.php";
session_start();
if (!isset($_SESSION["login"]))
    header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php"; ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->

        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "NavTop.php"; ?>
            <!-- Navbar End -->

            <?php
            include "config.php";

            if (isset($_POST['Add'])) {
                // Retrieve form data
                $Id = $_POST["ItemID"];
                $CN = $_POST["ItemName"];
                $IP = $_POST["ItemPrice"];
                $categoryId = $_POST["CategoryID"];
                $imageName = $_FILES['image']['name'];
                $imageTemp = $_FILES['image']['tmp_name'];
                $imagePath = 'images/' . $imageName;
                move_uploaded_file($imageTemp, $imagePath);
            
            echo    $Qry = "INSERT INTO menu_item (ItemID, ItemName, ItemPrice, CatagoryID, image_path)
                        VALUES ('$Id', '$CN', '$IP', '$categoryId', '$imagePath')";
            
              
                if (mysqli_query($con, $Qry)) {
                    echo '<script language="javascript">alert("All Data has been successfully inserted!"); window.location.href = "MenuItem.php";</script>';
                } else {
                    echo '<script language="javascript">alert("Something went wrong! Data was not inserted!"); window.back();</script>';
                }
            }
            ?>


            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row bg-light rounded align-items-center justify-content-center mx-0">
                    <div class="">
                        <div class="col-sm-12 col-xl-6">
                            <div class="bg-light rounded h-100 p-4">
                                <h6 class="mb-4">Add Menu Item</h6>
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="row mb-4">
                                        <label for="ItemID" class="col-sm-4 col-form-label">Item ID</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="ItemID" name="ItemID">
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label for="ItemName" class="col-sm-4 col-form-label">Item Name</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="ItemName" name="ItemName" required>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label for="ItemPrice" class="col-sm-4 col-form-label">Item Price</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="ItemPrice" name="ItemPrice" required>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
    <label for="ItemPrice" class="col-sm-4 col-form-label">Category</label>
    <div class="col-sm-8">
        <select class="form-select mb-3" aria-label="Default select example" name="CategoryID">
            <?php
            $query = "SELECT CatagoryID, CatagoryName FROM menu_catagory";
            $result = mysqli_query($con, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                $categoryId = $row['CatagoryID'];
                $categoryName = $row['CatagoryName'];
                echo "<option value='$categoryId'>$categoryName</option>";
            }
            ?>
        </select>
    </div>
</div>

                                   
                                    <div class="row mb-4">
                                        <label for="Image" class="col-sm-4 col-form-label">Image</label>
                                        <div class="col-sm-8">
                                            <input type="file" class="form-control" id="Image" name="image" accept="image/*" required>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary" name="Add">Add Item</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Blank End -->

            <!-- Footer Start -->
            <?php include "Footer.php"; ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
