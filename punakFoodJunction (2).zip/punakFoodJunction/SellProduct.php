<?php
require_once "config.php";
session_start();

// ...
if (isset($_POST["submit"])) {
    // Retrieve data from the cart (assuming cart is stored in session)
    $cart = json_decode($_POST['cart'], true);

    // Generate a unique OrderID for this order
    $new_order_id = sprintf("ORDER%04d", $_SESSION['order_number']);
    $date = date('Y-m-d H:i:s');

    foreach ($cart as $item) {
        $itemName = mysqli_real_escape_string($con, $item['name']);
        $itemPrice = $item['price'];
        $quantity = $item['quantity'];
        $totalPrice = $item['price'] * $quantity;

        $query = "INSERT INTO orders (OrderID, Date, itemName, itemPrice, quantity, totalPrice) 
                  VALUES ('$new_order_id', '$date', '$itemName', $itemPrice, $quantity, $totalPrice)";

        if (mysqli_query($con, $query)) {
            // Order details inserted successfully
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($con);
        }
    }

    $_SESSION['order_number']++; // Increment the order number once the order is complete

    echo '<script language="javascript">alert("Order submitted successfully!");</script>';
}

// ...


?>







<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php"; ?>
    
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->

        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "NavTop.php"; ?>
            <!-- Navbar End -->

            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row  bg-light rounded align-items-center justify-content-center mx-0">
                    <div class="">
                        
                        <div class="col-sm-12 col-xl-6">
                            <div class="bg-light rounded h-100 p-4">
                                <h6 class="mb-4">Sell Product</h6>
                                <form action="" method="POST" enctype="multipart/form-data">
                                    

                                    <div class="row mb-4">
                                        <label for="SName" class="col-sm-4 col-form-label">Category</label>
                                        <div class="col-sm-8">
                                            <select id="CID" name="CID" class="form-select mb-3" aria-label="Default select example" onchange="getItems()">
                                                <option selected>Select Category</option>
                                                <?php
                                                $Qry = "SELECT DISTINCT CatagoryName, CatagoryID FROM menu_catagory ORDER BY CatagoryName";
                                                $res = mysqli_query($con, $Qry);
                                                while ($r = mysqli_fetch_array($res)) {
                                                    echo '<option value="' . $r["CatagoryID"] . '">' . $r["CatagoryName"] . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                   

                                    <!-- <button type="submit" class="btn btn-primary" name="Apply">Apply</button> -->
                                </form>
                            

                            </div>
                        </div>
                        <div id="itemList" class="row"></div>
                       <!-- Assuming you have a cart element with id="cart" -->

  <!-- Add this code where you want the cart box to appear -->
  <!-- Add this code where you want to display the cart -->
<div id="cart" class="cart-box mt-4">
    <h5 class="mb-3">Cart</h5>
    <table class="table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Item Price</th>
                <th>Quantity</th>
                <th>Total Price</th>
                
            </tr>
           
    

        </thead>
        <tbody id="cart-items">
            <!-- Cart items will be dynamically added here -->
        </tbody>
        <tr>
           
    <td colspan="2"><td><strong>Grand Total:</strong> </td><td><span id="grand-total">$0.00</span></td></td>
    

           </tr>
    </table>
    <form action="" method="POST">
    <input type="hidden" name="cart" id="cartData" value="" />
    <!-- Other form inputs -->
    <button type="submit" name="submit" class="btn btn-primary">Submit Order</button>
</form>


    
</div>




                    </div>
                </div>
            </div>
            <!-- Blank End -->

            <!-- Footer Start -->
            <?php include "Footer.php"; ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script>
    document.getElementById('CID').addEventListener('change', function() {
        getItems();
    });
</script>
<script>
    function getItems() {
        var selectedCategory = document.getElementById('CID').value;

        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'getitems1.php?category=' + selectedCategory, true);

        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 400) {
                // Success, update the itemList div with fetched items
                document.getElementById('itemList').innerHTML = xhr.responseText;
            } else {
                // Error handling
                console.error('Error fetching items: ' + xhr.statusText);
            }
        };

        xhr.onerror = function() {
            console.error('Network error');
        };

        xhr.send();
    }
</script>
<script>
    let cart = [];

    function addToCart(itemId, itemName, itemPrice) {
        let existingItem = cart.find(item => item.id === itemId);

        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ id: itemId, name: itemName, price: itemPrice, quantity: 1 });
        }

        updateCartUI();
    }

    function updateCartItemQuantity(itemId, action) {
    let cartItem = cart.find(item => item.id === itemId);
    if (cartItem) {
        let quantityElement = document.querySelector(`#quantity-${itemId}`);
        let totalElement = document.querySelector(`#total-${itemId}`);
        
        if (action === 'increase') {
            cartItem.quantity++;
        } else if (action === 'decrease' && cartItem.quantity > 1) {
            cartItem.quantity--;
        }
        
        // Update the quantity and total in the UI
        quantityElement.textContent = cartItem.quantity;
        cartItem.totalPrice = cartItem.price * cartItem.quantity; // Update total price
        totalElement.textContent = '$' + cartItem.totalPrice;
    }
    updateCartUI();
}

function calculateGrandTotal() {
    let grandTotal = 0;
    cart.forEach(item => {
        grandTotal += item.totalPrice;
    });
    return grandTotal;
}
function updateCartUI() {
    let cartElement = document.getElementById('cart-items');
    cartElement.innerHTML = '';

    let grandTotal = 0; // Initialize grand total

    cart.forEach(item => {
        item.totalPrice = item.price * item.quantity;
        let tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${item.name}</td>
            <td>$${item.price}</td>
            <td>
                <span id="quantity-${item.id}" class="mx-2">${item.quantity}</span>
            </td>
            <td>$${item.totalPrice}</td>
        `;
        cartElement.appendChild(tr);

        grandTotal += item.totalPrice; // Add item's total price to grand total
    });

    // Update the grand total
    let grandTotalElement = document.getElementById('grand-total');
    grandTotalElement.textContent = '$' + grandTotal.toFixed(2);
    document.getElementById('cartData').value = JSON.stringify(cart);
}



    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('add-to-cart')) {
            let itemId = event.target.dataset.id;
            let itemName = event.target.dataset.name;
            let itemPrice = event.target.dataset.price;
            addToCart(itemId, itemName, itemPrice);
        }
    });
</script>

   
</body>

</html>
