<?php
require_once "config.php";
session_start();
if (!isset($_SESSION["login"]))
    header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php"; ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <!-- Code for spinner -->
        <!-- Spinner End -->

        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->

        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "NavTop.php"; ?>
            <!-- Navbar End -->

            <?php
            
            // Fetch the data of the menu item to be edited
            $Qry = "SELECT * FROM menu_item WHERE ID=" . $_GET["EditID"];
            $r = mysqli_query($con, $Qry);
            $row = mysqli_fetch_array($r);
           
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Update"])) {
                $id = $_POST["id"];
                $itemId = $_POST["ItemId"];
                $itemName = $_POST["ItemName"];
                $itemPrice = $_POST["ItemPrice"];
                $categoryID = $_POST["CategoryID"];
            
                // Check if a new image was uploaded
                if ($_FILES["image"]["tmp_name"] != "") {
                    $imageName = $_FILES['image']['name'];
                    $imageTemp = $_FILES['image']['tmp_name'];
                    $imagePath = 'images/' . $imageName;
                    move_uploaded_file($imageTemp, $imagePath);
                    $updateQuery = "UPDATE menu_item SET ItemID='$itemId', ItemName='$itemName', ItemPrice='$itemPrice', CatagoryID='$categoryID', image_path='$imagePath' WHERE ID='$id'";
                } else {
                    $updateQuery = "UPDATE menu_item SET ItemID='$itemId', ItemName='$itemName', ItemPrice='$itemPrice', CatagoryID='$categoryID' WHERE ID='$id'";
                }
            
                if (mysqli_query($con, $updateQuery)) {
                    echo '<script language="javascript">alert("All Data has been successfully Updated!"); window.location.href = "MenuItem.php";</script>';
                } else {
                    echo '<script language="javascript">alert("Something went wrong! Data was not Updated!"); window.history.back();</script>';
                }
            }
            
?>

            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row bg-light rounded align-items-center  mx-0">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Update Item</h6>
                            <!-- Modify the form action to point to the current page -->
                            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
                                <div class="row mb-4">
                                    <label for="Seme" class="col-sm-4 col-form-label"></label>
                                    <div class="col-sm-8">
                                        <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row["ID"]; ?>" required>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="ItemId" class="col-sm-4 col-form-label">Item Id</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ItemId" name="ItemId" value="<?php echo $row["ItemID"]; ?>" required>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="ItemName" class="col-sm-4 col-form-label">Item Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ItemName" name="ItemName" value="<?php echo $row["ItemName"]; ?>">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="ItemPrice" class="col-sm-4 col-form-label">Item Price</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ItemPrice" name="ItemPrice" value="<?php echo $row["ItemPrice"]; ?>">
                                    </div>
                                </div>
                                <!-- Add form fields for the category and image -->
                                <div class="row mb-4">
                                    <label for="CategoryID" class="col-sm-4 col-form-label">Category ID</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="CategoryID" name="CategoryID" value="<?php echo $row["CatagoryID"]; ?>">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="Image" class="col-sm-4 col-form-label">Current Image</label>
                                    <div class="col-sm-8">
                                        <img src="<?php echo $row['image_path']; ?>" alt="Current Image" width="50">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="NewImage" class="col-sm-4 col-form-label">New Image</label>
                                    <div class="col-sm-8">
                                        <input type="file" class="form-control" id="NewImage" name="image" accept="image/*">
                                    </div>
                                </div>
                                <!-- Modify the button name to "Update" -->
                                <button type="submit" class="btn btn-primary" name="Update">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Blank End -->

            <!-- Footer Start -->
            <?php include "Footer.php"; ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
