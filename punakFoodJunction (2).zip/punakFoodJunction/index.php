<?php
require_once "config.php";
session_start();
if(!isset($_SESSION["login"]))
header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php";?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php 
        include "SideBar.php";
        ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
           <?php include "NavTop.php";?>
            <!-- Navbar End -->


            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-primary"></i>
                            
                                <div class="ms-3">
    <p class="mb-2">Today Sale</p>
    <?php
    $currentDate = date("Y-m-d");
    $sql = "SELECT * FROM orders where date= '$currentDate'";
    $result = mysqli_query($con, $sql);

    $totalSum = 0; // Initialize total sum variable

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $totalPrice = $row["totalPrice"];
            // Add the current total price to the total sum
            $totalSum += $totalPrice;
        }

        // Output the total sum
        echo "<h6 class='mb-0'><strong>$totalSum tk</strong></h6>";
    } else {
        echo "Error fetching buy_items: " . mysqli_error($con);
    }
    ?>
</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
    <p class="mb-2">Today Expend</p>
    <?php
    $currentDate = date("Y-m-d");
    $sql = "SELECT * FROM buy_product WHERE Date = '$currentDate'";
    $result = mysqli_query($con, $sql);

    $totalSum = 0; // Initialize total sum variable

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $totalPrice = $row["TotalPrice"];
            // Add the current total price to the total sum
            $totalSum += $totalPrice;
        }

        // Output the total sum
        echo "<h6 class='mb-0'><strong>$totalSum tk</strong></h6>";
    } else {
        echo "Error fetching buy_items: " . mysqli_error($con);
    }
    ?>
</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-area fa-3x text-primary"></i>
                            <div class="ms-3">
    <p class="mb-2">Monthly Sell</p>
    <?php
    $currentMonth = date("m");
    $currentYear = date("Y");

    $firstDayOfMonth = date("$currentYear-$currentMonth-01");
    $lastDayOfMonth = date("Y-m-t", strtotime($firstDayOfMonth));

    $sql = "SELECT * FROM orders WHERE date BETWEEN '$firstDayOfMonth' AND '$lastDayOfMonth'";
    $result = mysqli_query($con, $sql);

    $totalSum = 0; // Initialize total sum variable

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $totalPrice = $row["totalPrice"];
            // Add the current total price to the total sum
            $totalSum += $totalPrice;
        }

        // Output the total sum
        echo "<h6 class='mb-0'><strong>$totalSum tk</strong></h6>";
    } else {
        echo "Error fetching buy_items: " . mysqli_error($con);
    }
    ?>
</div>

                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-primary"></i>
                            <div class="ms-3">
    <p class="mb-2">Monthly Expend</p>
    <?php
    $currentMonth = date("m");
    $currentYear = date("Y");

    $firstDayOfMonth = date("$currentYear-$currentMonth-01");
    $lastDayOfMonth = date("Y-m-t", strtotime($firstDayOfMonth));

    $sql = "SELECT * FROM buy_product WHERE Date BETWEEN '$firstDayOfMonth' AND '$lastDayOfMonth'";
    $result = mysqli_query($con, $sql);

    $totalSum = 0; // Initialize total sum variable

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $totalPrice = $row["TotalPrice"];
            // Add the current total price to the total sum
            $totalSum += $totalPrice;
        }

        // Output the total sum
        echo "<h6 class='mb-0'><strong>$totalSum tk</strong></h6>";
    } else {
        echo "Error fetching buy_items: " . mysqli_error($con);
    }
    ?>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sale & Revenue End -->


            <!-- Sales Chart Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Daily Sell Report</h6>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Item Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Unit Price</th>
                                        <th scope="col">Total Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                               
                                <?php
$currentDate = date("Y-m-d");
$sql = "SELECT * FROM orders where date= '$currentDate' LIMIT 10";
$result = mysqli_query($con, $sql);

$totalSum = 0; // Initialize total sum variable

if ($result) {
    while($row = $result->fetch_assoc()) {
        $itemID = $row["OrderID"];
                            $itemName = $row["itemName"];
                            $quantity = $row["quantity"];
                            $unitPrice = $row["itemPrice"];
                            $totalPrice = $row["totalPrice"];
                    

       

        // Add the current total price to the total sum
        $totalSum += $totalPrice;

        // Output the data
        echo "<tr>";
        echo "<td>$itemName</td>";
        echo "<td>$quantity</td>";
        echo "<td>$unitPrice</td>";
        echo "<td>$totalPrice</td>";
        echo "</tr>";
    }

    // Output the total sum row
    echo "<tr>";
    echo "<td colspan='3' class='text-end'><strong>Total:</strong></td>";
    echo "<td><strong>$totalSum</strong></td>";
    echo "</tr>";
} else {
    echo "Error fetching buy_items: " . mysqli_error($con);
}
?>
       
                                </tbody>
                            </table>
                        </div>
                    </div>
                        
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Daily Buying Products</h6>
<table class="table">
    <thead>
        <tr>
            <th scope="col">Item Name</th>
            <th scope="col">Quantity</th>
            <th scope="col">Unit Price</th>
            <th scope="col">Total Price</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $currentDate = date("Y-m-d");
        $sql = "SELECT * FROM buy_product WHERE Date = '$currentDate' LIMIT 10";
        $result = mysqli_query($con, $sql);

        $totalSum = 0; // Initialize total sum variable

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                // Assuming you have code here to fetch and display individual item data

                // Calculate and add the current total price to the total sum
                $totalSum += $row['TotalPrice'];

                // Output the data for the current item
                echo "<tr>";
                
                echo "<td>" . $row['ItemName'] . "</td>";
                echo "<td>" . $row['Quantity'] . "</td>";
                echo "<td>" . $row['UnitePrice'] . "</td>";
                echo "<td>" . $row['TotalPrice'] . "</td>";
                
                echo "</tr>";
            }

            // Output the total sum row
            echo "<tr>";
            echo "<td colspan='3' class='text-end'><strong>Total:</strong></td>";
            echo "<td><strong>$totalSum</strong></td>";
            echo "</tr>";
        } else {
            echo "Error fetching buy_product: " . mysqli_error($con);
        }
        ?>
    </tbody>
</table>

                        </div>
                    </div>
            <!-- Sales Chart End -->
            </div>
                    </div>

            <!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
    <div class="row bg-light rounded align-items-center mx-0">
        <div class="">
            <h3>Invoice</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Order No</th>
                        <th scope="col">Order Date</th>
                        <th scope="col">Action</th>
                        <th scope="col">Item Name</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Unit Price</th>
                        <th scope="col">Total Price</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT DISTINCT OrderID, Date FROM orders ORDER BY `orders`.`OrderID` DESC LIMIT 5"; // Retrieve unique OrderIDs
                    $result = mysqli_query($con, $sql);

                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $orderID = $row['OrderID'];
                            $orderDate = $row['Date'];

                            // Retrieve data for the current OrderID
                            $orderItemsQuery = "SELECT * FROM orders WHERE OrderID = '$orderID'";
                            $orderItemsResult = mysqli_query($con, $orderItemsQuery);

                            if ($orderItemsResult) {
                                $firstRow = true;
                                while ($item = $orderItemsResult->fetch_assoc()) {
                                    // Output the data
                                    if($firstRow){
                                        echo "<tr>";
                                        echo "<td rowspan='".mysqli_num_rows($orderItemsResult)."'>$item[OrderID]</td>";
                                        echo "<td rowspan='".mysqli_num_rows($orderItemsResult)."'>$orderDate</td>";
                                        echo "<td rowspan='".mysqli_num_rows($orderItemsResult)."'><a href='invoice.php?order_id=$orderID' class='btn btn-primary'>Invoice</a></td>";
                                        $firstRow = false;
                                    } else {
                                        echo "<tr>";
                                    }
                                    echo "<td>$item[itemName]</td>";
                                    echo "<td>$item[quantity]</td>";
                                    echo "<td>$item[itemPrice]</td>";
                                    echo "<td>$item[totalPrice]</td>";
                                    echo "<td > </td>";

                                    echo "</tr>";
                                }
                            } else {
                                echo "Error fetching order items: " . mysqli_error($con);
                            }
                           
                        }
                    } else {
                        echo "Error fetching OrderIDs: " . mysqli_error($con);
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

            <!-- Recent Sales End -->




            <!-- Footer Start -->
           <?php include "Footer.php";?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
   <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>