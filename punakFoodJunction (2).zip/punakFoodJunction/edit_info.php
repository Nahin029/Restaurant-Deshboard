<?php
require_once "config.php";
session_start();
if (!isset($_SESSION["login"])) {
    header("location: signin.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("location: viewStuff.php");
    exit();
}

$id = $_GET['id'];

// Retrieve the existing data for the stuff with the given ID
$stmt = $con->prepare("SELECT * FROM stuff WHERE ID = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    echo '<script language="javascript">alert("Stuff not found!"); window.location.href = "viewStuff.php";</script>';
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle the form submission
    $EName = $_POST["EName"];
    $FName = $_POST["FName"];
    $Gender = $_POST["gridRadios"];
    $Category = $_POST["gridRadios1"];
    $Mobile = $_POST["mobile"];
    $Address = $_POST["Address"];

    // Update the stuff information in the database
    $stmt = $con->prepare("UPDATE stuff SET EName=?, FName=?, Gander=?, Catogry=?, Mobile=?, Address=?, Image=? WHERE ID=?");
    $stmt->bind_param("sssssssi", $EName, $FName, $Gender, $Category, $Mobile, $Address, $image, $id);

    // Check if a new image file is uploaded
    if ($_FILES["image"]["tmp_name"]) {
        $target_dir = "images/";
        $image = $target_dir . basename($_FILES["image"]["name"]);

        // Delete the previous image file if it exists
        if (!empty($row['Image']) && file_exists($row['Image'])) {
            unlink($row['Image']);
        }

        // Move the uploaded image file to the target directory
        move_uploaded_file($_FILES["image"]["tmp_name"], $image);
    } else {
        // Use the previous image if no new image is uploaded
        $image = $row['Image'];
    }

    if ($stmt->execute()) {
        echo '<script language="javascript">alert("Stuff information updated successfully!"); window.location.href = "viewStuff.php";</script>';
        exit();
    } else {
        echo '<script language="javascript">alert("Something went wrong! Stuff information was not updated."); window.back();</script>';
    }

    $stmt->close();
}

// Close the database connection
$con->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php"; ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "NavTop.php"; ?>
            <!-- Navbar End -->

            <!-- Edit Stuff Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row bg-light rounded align-items-center justify-content-center mx-0">
                    <div class="col-md-6">
                        <h3 style="margin:20px">Edit Stuff Information</h3>
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="EName" class="form-label">Employee Name</label>
                                <input type="text" class="form-control" id="EName" name="EName" value="<?php echo $row['EName']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="FName" class="form-label">Father's Name</label>
                                <input type="text" class="form-control" id="FName" name="FName" value="<?php echo $row['FName']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Gender</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios" value="Male" <?php echo ($row['Gander'] == 'Male') ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="gridRadios1">
                                        Male
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios" value="Female" <?php echo ($row['Gander'] == 'Female') ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="gridRadios2">
                                        Female
                                    </label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gridRadios1" id="gridRadios1" value="Category1" <?php echo ($row['Catogry'] == 'Category1') ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="gridRadios3">
                                    Manager
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gridRadios1" id="gridRadios1" value="Category2" <?php echo ($row['Catogry'] == 'Category2') ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="gridRadios4">
                                    Cheaf
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gridRadios1" id="gridRadios1" value="Category2" <?php echo ($row['Catogry'] == 'Category2') ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="gridRadios4">
                                    Waiter
                                    </label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="mobile" class="form-label">Mobile</label>
                                <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $row['Mobile']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="Address" class="form-label">Address</label>
                                <textarea class="form-control" id="Address" name="Address" required><?php echo $row['Address']; ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="image" class="form-label">Image</label>
                                <?php if (!empty($row['Image'])) : ?>
                                    <div class="mb-2">
                                        <img src="<?php echo $row['Image']; ?>" alt="Previous Image" width="150">
                                    </div>
                                <?php endif; ?>
                                <input type="file" class="form-control" id="image" name="image">
                            </div>
                            
                            <div class="mb-3">
                                <input type="submit" class="btn btn-primary" value="Update">
                                <a href="viewStuff.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Edit Stuff Form End -->

            <!-- Footer Start -->
            <?php include "Footer.php"; ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
