<?php
require_once "config.php";
session_start();
if(!isset($_SESSION["login"]))
header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php";?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
           <?php include "NavTop.php"; ?>
            <!-- Navbar End -->


            <script>
               function preview() {
   thumb.src=URL.createObjectURL(event.target.files[0]);
}
            </script>
            <?php
include "config.php";

if (isset($_POST['Apply'])) {
    $EN = $_POST["EName"];
    $FN = $_POST["FName"];
    $GA = $_POST["gridRadios"];
    $CA = $_POST["gridRadios1"];
    $MO = $_POST["mobile"];
    $ADD = $_POST["Address"];

    // Handle the uploaded image
    $image = $_FILES['StuPhoto']['name'];
    $image_tmp = $_FILES['StuPhoto']['tmp_name'];
    $image_extension = pathinfo($image, PATHINFO_EXTENSION);
    $valid_extensions = array("jpg", "jpeg", "png");

    // Check if the uploaded file has a valid extension
    if (in_array($image_extension, $valid_extensions)) {
        // Generate a unique name for the image
        $image_name = uniqid() . '.' . $image_extension;

        // Move the uploaded file to the desired location
        $image_path = "images/" . $image_name;
        move_uploaded_file($image_tmp, $image_path);

        // Insert the image path into the database along with other data
        $qry = "INSERT INTO stuff (EName, FName, Gander, Catogry, Mobile, Address, Image)
                VALUES ('$EN', '$FN', '$GA', '$CA', '$MO', '$ADD', '$image_path')";

        if (mysqli_query($con, $qry)) {
            echo '<script language="javascript">alert("All Data has been successfully inserted!"); window.location.href = "index.php";</script>';
        } else {
            echo '<script language="javascript">alert("Something went wrong! Data was not inserted!"); window.back();</script>';
        }
    } else {
        echo '<script language="javascript">alert("Invalid file format! Only JPG, JPEG, and PNG images are allowed."); window.back();</script>';
    }
}
?>



   

            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row  bg-light rounded align-items-center justify-content-center mx-0">
                    <div class="">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Stuff Information</h6>
                            <form action="" method="POST" enctype="multipart/form-data">
                            <!-- <div class="row mb-4" >
                                    <label for="SID" class="col-sm-4 col-form-label">Stuff ID</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="SID" name="SID" required>
                                    </div>
                                </div> -->
                                <div class="row mb-4" >
                                    <label for="EName" class="col-sm-4 col-form-label">Emplay Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="EName" name="EName">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="FName" class="col-sm-4 col-form-label">Fathers's Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="FName" name="FName">
                                    </div>
                                </div>
                        
                               
                                <fieldset class="row mb-4">
                                    <legend class="col-form-label col-sm-4 pt-0">Gander</legend>
                                    <div class="col-sm-8">
                                        <div class="form-check" style="display: inline-block;">
                                            <input class="form-check-input" type="radio" name="gridRadios"
                                                id="gridRadios1" value="Male" checked>
                                            <label class="form-check-label" for="gridRadios1">
                                                Male
                                            </label>
                                        </div>
                                        <div class="form-check" style="display: inline-block;">
                                            <input class="form-check-input" type="radio" name="gridRadios"
                                                id="gridRadios2" value="Female">
                                            <label class="form-check-label" for="gridRadios2">
                                                Female
                                            </label>
                                        </div>
                                        <div class="form-check" style="display: inline-block;">
                                            <input class="form-check-input" type="radio" name="gridRadios"
                                                id="gridRadios2" value="Other">
                                            <label class="form-check-label" for="gridRadios2">
                                                Other
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset class="row mb-4">
                                    <legend class="col-form-label col-sm-4 pt-0">Catogry</legend>
                                    <div class="col-sm-8">
                                        <div class="form-check" style="display: inline-block;">
                                            <input class="form-check-input" type="radio" name="gridRadios1"
                                                id="gridRadios1" value="Manager" checked>
                                            <label class="form-check-label" for="gridRadios1">
                                                Manager
                                            </label>
                                        </div>
                                        <div class="form-check" style="display: inline-block;">
                                            <input class="form-check-input" type="radio" name="gridRadios1"
                                                id="gridRadios2" value="Cheaf">
                                            <label class="form-check-label" for="gridRadios2">
                                                Cheaf
                                            </label>
                                        </div>
                                        <div class="form-check" style="display: inline-block;">
                                            <input class="form-check-input" type="radio" name="gridRadios1"
                                                id="gridRadios2" value="Waiter">
                                            <label class="form-check-label" for="gridRadios2">
                                                Waiter
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                                
                                <div class="row mb-4">
                                    <label for="mobile" class="col-sm-4 col-form-label">Mobile</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="mobile" name="mobile">
                                    </div>
                                </div>
								
                                
                                <div class="row mb-4">
                                    <label for="Addres" class="col-sm-4 col-form-label">Address</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="Address" name="Address">
                                    </div>
                                </div>
                               
								<div class="row mb-4">
    <label for="StuPhoto" class="col-sm-4 col-form-label">Image</label>
    <div class="col-sm-8">
        
        <input type="file" class="form-control" id="StuPhoto" name="StuPhoto" accept="image/png, image/jpeg, image/png" onchange="preview()">  
                                        <img id="thumb" src="" width="150px" style="margin:10px"/>
    </div>
</div>

                                <button type="submit" class="btn btn-primary" name="Apply">Apply </button>
                            </form>
                        </div>
                    </div>
					
                    </div>
                </div>
            </div>
            <!-- Blank End -->


            <!-- Footer Start -->
            <?php include "Footer.php";?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>