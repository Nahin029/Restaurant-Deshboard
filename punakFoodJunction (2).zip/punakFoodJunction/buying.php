<?php
require_once "config.php";
session_start();
if(!isset($_SESSION["login"]))
header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php";?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <!-- <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div> -->
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
           <?php include "NavTop.php"; ?>
            <!-- Navbar End -->


            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                        <h6 class="mb-4">Daily Buying Products</h6>
<table class="table">
    <thead>
        <tr>
            <th scope="col">Item Name</th>
            <th scope="col">Quantity</th>
            <th scope="col">Unit Price</th>
            <th scope="col">Total Price</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $currentDate = date("Y-m-d");
        $sql = "SELECT * FROM buy_product WHERE Date = '$currentDate'";
        $result = mysqli_query($con, $sql);

        $totalSum = 0; // Initialize total sum variable

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                // Assuming you have code here to fetch and display individual item data

                // Calculate and add the current total price to the total sum
                $totalSum += $row['TotalPrice'];

                // Output the data for the current item
                echo "<tr>";
                
                echo "<td>" . $row['ItemName'] . "</td>";
                echo "<td>" . $row['Quantity'] . "</td>";
                echo "<td>" . $row['UnitePrice'] . "</td>";
                echo "<td>" . $row['TotalPrice'] . "</td>";
                
                echo "</tr>";
            }

            // Output the total sum row
            echo "<tr>";
            echo "<td colspan='3' class='text-end'><strong>Total:</strong></td>";
            echo "<td><strong>$totalSum</strong></td>";
            echo "</tr>";
        } else {
            echo "Error fetching buy_product: " . mysqli_error($con);
        }
        ?>
    </tbody>
</table>

                        </div>
                    </div>

                    <div class="col-sm-12 col-xl-6">
    <div class="bg-light rounded h-100 p-4">
        <h6 class="mb-4">Selected Date Report</h6>
        <form method="POST" class="row g-2 align-items-center">
    <div class="col-auto">
        <label for="fromDate" class="form-label">From Date:</label>
        <input type="date" class="form-control" id="fromDate" name="fromDate" required>
    </div>
    <div class="col-auto">
        <label for="toDate" class="form-label">To Date:</label>
        <input type="date" class="form-control" id="toDate" name="toDate" required>
    </div>
    <div class="col-auto">
        <button type="submit" name="submit" class="btn btn-primary" style="margin-top:30px;">Show Data</button>
    </div>
</form>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Item Name</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Total Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if(isset($_POST['submit'])) {
                    $fromDate = $_POST['fromDate'];
                    $toDate = $_POST['toDate'];

                    $sql = "SELECT * FROM buy_product WHERE Date BETWEEN '$fromDate' AND '$toDate'";
                    $result = mysqli_query($con, $sql);

                    $totalSum = 0; // Initialize total sum variable

                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Assuming you have code here to fetch and display individual item data
            
                            // Calculate and add the current total price to the total sum
                            $totalSum += $row['TotalPrice'];
            
                            // Output the data for the current item
                            echo "<tr>";
                            
                            echo "<td>" . $row['ItemName'] . "</td>";
                            echo "<td>" . $row['Quantity'] . "</td>";
                            echo "<td>" . $row['UnitePrice'] . "</td>";
                            echo "<td>" . $row['TotalPrice'] . "</td>";
                            
                            echo "</tr>";
                        }
            
                        // Output the total sum row
                        echo "<tr>";
                        echo "<td colspan='3' class='text-end'><strong>Total:</strong></td>";
                        echo "<td><strong>$totalSum</strong></td>";
                        echo "</tr>";
                    } else {
                        echo "Error fetching buy_product: " . mysqli_error($con);
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

                </div>
            </div>
            <!-- Blank End -->


            <!-- Footer Start -->
            <?php include "Footer.php";?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>