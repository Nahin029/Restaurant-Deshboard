<?php
require_once "config.php";

if(isset($_GET["item"])) {
    $itemID = $_GET["item"];

    // Sanitize the input to prevent SQL injection
    $itemID = mysqli_real_escape_string($con, $itemID);

    // Query to retrieve the price of the selected item
    $getItemPriceQuery = "SELECT ItemPrice FROM menu_item WHERE ItemID = '$itemID'";
    $result = mysqli_query($con, $getItemPriceQuery);

    if($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $itemPrice = $row["ItemPrice"];
        echo $itemPrice;
    } else {
        echo "Error: Unable to fetch item price.";
    }
} else {
    echo "Error: Invalid request.";
}
?>
