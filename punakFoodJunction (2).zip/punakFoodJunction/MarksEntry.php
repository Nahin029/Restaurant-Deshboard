<?php
require_once "config.php";
session_start();
if(!isset($_SESSION["login"]))
header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php";?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
           <?php include "NavTop.php"; ?>
            <!-- Navbar End -->


            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
            <?php

require_once "config.php";

$val="";
if(isset($_POST['Apply'])){
	for($i=0; $i<count($_POST["PgdId"]);$i++){
		
		$SId= $_POST["PgdId"][$i];
		$AttenMarks= (int)$_POST["AttenMarks"][$i];
		$CTMarks= (int)$_POST["CTMarks"][$i];
		$PraMarks= (int)$_POST["PraMarks"][$i];
		$FinalMarks= (int)$_POST["FinalMarks"][$i];
		$TotalMarks=$AttenMarks+$CTMarks+$PraMarks+$FinalMarks;

		$val = $val. "('$SId','$AttenMarks','$CTMarks','$PraMarks','$FinalMarks','$TotalMarks'),";
	}

	$val = rtrim($val, ",");
	
	$Qry="Insert into marks (PGD_ID,Atn,CT,Pra,Fnl,Tot) values ". $val .";";
	
	if(mysqli_query($con,$Qry)){
		echo '<script language="javascript">alert("All Data has been sucessfully inserted!!! "); </script>';
	}
	else {
		echo '<script language="javascript">alert("Somthing wrong!! Data is not inserted!!! "); window.back();</script>';
	}
	
}


$Qry="SELECT * FROM STUDENT ORDER BY PGD_ID ASC";
$r=mysqli_query($con,$Qry);



$t=1;
?>
<form action="" method="POST" enctype="multipart/form-data">

<div class="row" style="display: inline-block;">
	<div style="float: left; display: inline-block;">
		<select class="form-control">
			<option value=""> Batch </option>
			<?php
				for($i=18;$i>=13; $i--)
					echo '<option value="'. $i .'"> '. $i .'th</option>';
			?>
		</select >
	</div>
</div>
<table class="table table-striped table-hover">
    <tr>
        <th>sn</th>
        <th>PGD ID</th>
        <th>photo</th>
        <th>Student Name</th>
        <th>Atten<br>(10%)</th>
        <th>CT<br>(30%)</th>
        <th>Pra<br>(30%)</th>
        <th>Final<br>(30%)</th>
    </tr>	
<?php 


    while($l=mysqli_fetch_array($r)){
	
	$Qry1="SELECT * FROM marks where PGD_ID=". $l["PGD_ID"];
	//$a=mysqli_query($con,$Qry1);
    // $h=mysqli_fetch_array($a);
	
	
	echo "<tr>";
    echo "<td>". $t++ ."</td>";
    echo "<td><input type='hidden' name='PgdId[]' size='8' value=". $l["PGD_ID"] .">".$l["PGD_ID"]."</td>";
    echo "<td><a href='StudentDetails.php?ID=". $l["ID"] ."'><img src='" . $l["Photo"] . "' width='30px;' height='50px;'></a></td>";
    echo "<td>".$l["SName"]."</td>";
    echo "<td><input type='text' name='AttenMarks[]' size='4' value=". $h["Atn"] ."></td>";
    echo "<td><input type='text' name='CTMarks[]' size='4' value=". $h["CT"] ."></td>";
    echo "<td><input type='text' name='PraMarks[]' size='4' value=". $h["Pra"] ."></td>";
    echo "<td><input type='text' name='FinalMarks[]' size='4' value=". $h["Fnl"] ."></td>";
    
    echo "</tr>";
    
}

?>
</table>

								
		<button type="submit" class="btn btn-primary" name="Apply">Apply </button>
	</form>
            </div>
            <!-- Blank End -->
            
            <!-- Footer Start -->
            <?php include "Footer.php";?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>