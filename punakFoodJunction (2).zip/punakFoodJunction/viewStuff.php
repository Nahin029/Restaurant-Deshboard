<?php
require_once "config.php";
session_start();
if(!isset($_SESSION["login"]))
header("location: signin.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php";?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
           <?php include "NavTop.php"; ?>
            <!-- Navbar End -->
            <?php
require_once "config.php";
$query = "SELECT * FROM stuff";
$result = mysqli_query($con, $query);

require_once "config.php";

if (isset($_GET['Delid'])) {
    $ID = $_GET['Delid'];

    // Retrieve the image path from the database
    $stmt = $con->prepare("SELECT Image FROM stuff WHERE ID = ?");
    $stmt->bind_param("i", $ID);
    $stmt->execute();
    $stmt->bind_result($image);
    $stmt->fetch();
    $stmt->close();

    // Delete the image file if it exists
    if (!empty($image) && file_exists($image)) {
        if (unlink($image)) {
            // Image file deleted successfully

            // Prepare the delete statement
            $stmt = $con->prepare("DELETE FROM stuff WHERE ID = ?");
            $stmt->bind_param("i", $ID);

            // Execute the delete statement
            if ($stmt->execute()) {
                // Record and image deleted successfully
                echo '<script language="javascript">alert("Record and image deleted successfully!"); window.location.href = "viewStuff.php";</script>';
                exit();
            } else {
                // Error occurred while deleting the record
                echo '<script language="javascript">alert("Error deleting the record: '.$stmt->error.'"); window.back();</script>';
            }

            // Close the statement
            $stmt->close();
        } else {
            // Error occurred while deleting the image file
            echo '<script language="javascript">alert("Error deleting the image file"); window.back();</script>';
        }
    } else {
        // Image file not found or empty
        echo '<script language="javascript">alert("Image file not found or empty"); window.back();</script>';
    }
}

// Close the database connection
$con->close();
?>


            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row  bg-light rounded align-items-center justify-content-center mx-0">
                <table class="table table-striped table-hover">
                <div class="col-md-6 ">
                                <h3 style="margin-top:8px">Stuff List</h3>
                            </div>
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Father's Name</th>
            <th>Gender</th>
            <th>Category</th>
            <th>Mobile</th>
            <th>Address</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Iterate over the result set
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['EName'] . "</td>";
            echo "<td>" . $row['FName'] . "</td>";
            echo "<td>" . $row['Gander'] . "</td>";
            echo "<td>" . $row['Catogry'] . "</td>";
            echo "<td>" . $row['Mobile'] . "</td>";
            echo "<td>" . $row['Address'] . "</td>";
            echo "<td><img src='" . $row['Image'] . "' width='100px'></td>";
            echo "<td>";
            echo " <button type='submit' class='btn btn-primary'> <a style='color:white;' href='edit_info.php?id=" . $row['ID'] . "'><i class='fa fa-indent me'></i></a></button> ";
            echo "<button type='submit' class='btn btn-danger'> <a style='color:white;' href='viewStuff.php?Delid=" . $row['ID'] . "' onclick='return confirm(\"Are you sure you want to delete this record?\")'><i  class='fa fa-trash me'></i></a> </button>";
            echo "</td>";
           
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

                </div>
            </div>
            <!-- Blank End -->


            <!-- Footer Start -->
            <?php include "Footer.php";?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>