<?php
require_once "config.php";
session_start();
if (!isset($_SESSION["login"])) {
    header("location: signin.php");
    exit();
}

include "config.php";

if (isset($_POST['Apply'])) {
    $Dat = $_POST["Date"];
    
    $mn = $_POST["IID"];
    $ge = $_POST["Quantity"];
    $mob = $_POST["UnitPrice"];
    $totalPrice = $ge * $mob; // Calculate total price

    
       $Qry = "INSERT INTO buy_product (Date, ItemName, UnitePrice, Quantity, TotalPrice)
                VALUES ('$Dat', '$mn', '$mob','$ge', '$totalPrice')";

        if (mysqli_query($con, $Qry)) {
            echo '<script language="javascript">alert("All Data has been successfully inserted!");</script>';
        } else {
            echo '<script language="javascript">alert("Failed to insert data!");</script>';
        }
    }

  

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "Head.php"; ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "SideBar.php"; ?>
        <!-- Sidebar End -->

        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "NavTop.php"; ?>
            <!-- Navbar End -->

            <!-- Blank Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row  bg-light rounded align-items-center justify-content-center mx-0">
                    <div class="">
                        <div class="col-sm-12 col-xl-6">
                            <div class="bg-light rounded h-100 p-4">
                                <h6 class="mb-4">Buy Product</h6>
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="row mb-4">
                                        <label for="Date" class="col-sm-4 col-form-label">Date</label>
                                        <div class="col-sm-8">
                                            <input type="date" class="form-control" id="Date" name="Date" required>
                                        </div>
                                    </div>

                                   
                                    <div class="row mb-4">
                                        <label for="SName" class="col-sm-4 col-form-label">Item</label>
                                        <div class="col-sm-8">
                                            
                                            <input type="text" class="form-control" id="IID" name="IID" >
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label for="UnitPrice" class="col-sm-4 col-form-label">Unit Price</label>
                                        <div class="col-sm-8">
                                            <input type="number" class="form-control" id="UnitPrice" name="UnitPrice" onchange="calculateTotalPrice()">
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label for="Quantity" class="col-sm-4 col-form-label">Quantity</label>
                                        <div class="col-sm-8">
                                        <input type="text" class="form-control" id="Quantity" name="Quantity" oninput="validateInput(this)" onchange="calculateTotalPrice()">

<script>
function validateInput(input) {
    input.value = input.value.replace(/[^\d.]/g, ''); // Remove non-numeric and non-decimal characters
    if(input.value === '') {
        alert('Please enter a valid number.');
    }
}
</script>


                                        </div>
                                    </div>
                                   
                                    <div class="row mb-4">
                                        <label for="TotalPrice" class="col-sm-4 col-form-label">Total Price</label>
                                        <div class="col-sm-8">
                                            <input type="number" class="form-control" id="TotalPrice" name="TotalPrice" readonly>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary" name="Apply">Apply</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Blank End -->

            <!-- Footer Start -->
            <?php include "Footer.php"; ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <?php include "js.php"; ?>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script>
        function getItems() {
            var category = document.getElementById("CID").value;
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'getItems.php?category=' + category, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById("IID").innerHTML = xhr.responseText;
                    // After updating the items, trigger a change event on the item dropdown
                document.getElementById("IID").dispatchEvent(new Event('change'));
                }
            };
            xhr.send();
        }

        function calculateTotalPrice() {
            var quantity = document.getElementById("Quantity").value;
            var unitPrice = document.getElementById("UnitPrice").value;
            var totalPrice = quantity * unitPrice;
            document.getElementById("TotalPrice").value = totalPrice;
        }
        // Event listener for item dropdown change
    document.getElementById("IID").addEventListener('change', function() {
        var selectedItem = this.value;
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'getUnitPrice.php?item=' + selectedItem, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                document.getElementById("UnitPrice").value = xhr.responseText;
            }
        };
        xhr.send();
    });
    </script>
</body>

</html>
