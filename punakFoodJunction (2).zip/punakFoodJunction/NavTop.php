<nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <a href="index.php" class="navbar-brand mx-4 mb-3" style="margin-top:30px">
                    <h3 class="text-primary">Punak  Food junction</h3>
                </a>
                <div class="navbar-nav align-items-center ms-auto">
                
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <!-- <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;"> -->
                            <?php




include "config.php"; // Assuming this file contains your database connection

// Get username from session (assuming it's stored there after login)
$username = $_SESSION["login"];

// Query to get user data based on the username
$sql = "SELECT * FROM signin WHERE UserName = '$username'";
$result = mysqli_query($con, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);

    // Now you can use $userData to access user information, for example:
    $firstName = $userData["UserName"];
    

    // Output the username
    
} else {
    echo "Error fetching user data: " . mysqli_error($con);
}
?>

                            <span class="d-none d-lg-inline-flex"><?php echo "Welcome, $firstName "; ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <!-- <a href="#" class="dropdown-item">My Profile</a> -->
                            
                            <a href="signout.php" class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>